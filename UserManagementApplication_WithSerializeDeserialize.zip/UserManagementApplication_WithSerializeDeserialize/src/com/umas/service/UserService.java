package com.umas.service;

public interface UserService {
	
	public void insertDetailsOfUser();
	
	public void displayDetailsOfUser();
	
	public void updateUserDetails();
	
	public void deleteUser();

}
