package com.umas.service;

import java.util.Scanner;
import java.util.regex.Pattern;

import com.umas.model.User;

public class UserServiceImpl implements UserService {
	Scanner sc = new Scanner(System.in);

	User users[] = new User[5];

	@Override
	public void insertDetailsOfUser() {
		System.out.println("Enter No. of users Wanted To Create: ");
		int n = sc.nextInt();

		for (int i = 0; i < n; i++) {
			User user = new User();

			System.out.println("Enter User id:");
			int userId = sc.nextInt();
			user.setUserId(userId);

			String name = getValidUserName();
			user.setUserName(name);

			System.out.println("Enter User address:");
			String userAddress = sc.next();
			user.setUserAddress(userAddress);

			String userPanNo = checkPanCardNo();
			user.setUserPanNo(userPanNo);

			sc.nextLine();
			String userAdharNo = checkAadharCardNo();
			user.setUserAdharNo(userAdharNo);

			long contactNo = checkMobileNo();
			user.setContactNo(contactNo);

			String userEmailId = validEmail();
			user.setUserEmailId(userEmailId);

			users[i] = user;
			System.out.println("User added successfully!!");
		}

	}

	public String getValidUserName() {
		System.out.println("Enter User name:");
		String str = sc.next();
		if (Pattern.matches("[A-Za-z]+", str)) {
			return str;
		} else {
			System.out.println("Invalid User name..");

		}
		return getValidUserName();
	}

	public String checkAadharCardNo() {
		System.out.println("Enter User's Aadhar Card No:");
		String aadharCardNo = sc.nextLine();
		if (Pattern.matches("^[2-9]{1}[0-9]{3}[ -]?[0-9]{4}[ -]?[0-9]{4}$", aadharCardNo) && aadharCardNo.length() == 14
				&& aadharCardNo != null) {
			System.out.println("Valid Aadhar card no added");
		} else {
			System.out.println("Invalid Aadhar no.,It should be 12 digit number & it starts from any number between 2 to 9.");
			return checkAadharCardNo();
		}
		return aadharCardNo;
	}

	public String checkPanCardNo() {
		System.out.println("Enter User's Pan card No:");
		String panCardNo = sc.next();
		if (panCardNo.length() == 10 && Pattern.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}", panCardNo)) {
			return panCardNo;
		} else {
			System.out.println("Invalid Pan card Number");
		}
		return checkPanCardNo();
	}

	public long checkMobileNo() {
		System.out.println("Enter Mobile No:");
		long mobileNo = sc.nextLong();
		String s = String.valueOf(mobileNo);
		if (s.length() == 10 && Pattern.matches("[0-9]{10}", s)) {
			return mobileNo;
		} else {
			System.out.println("Invalid Mobile Number!!, please enter valid Mobile Number.");
		}
		return checkMobileNo();
	}

	private String validEmail() {
		System.out.println("Enter Your Email-Id: ");
		String mailId = sc.next();

		if (Pattern.matches("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}", mailId)) {
			System.out.println("Valid emailid added");
		} else {
			System.out.println("Invalid email id");
			return validEmail();
		}
		return mailId;
	}

	@Override
	public void displayDetailsOfUser() {
		for (User user : users) {
			if (user != null) {
				System.out.println(user);
			}
		}

	}

	@Override
	public void updateUserDetails() {
		System.out.println("Udate User's Details: ");
		boolean flag = true;
		System.out.println("Enter User id you want to upadate:");
		int user_id = getValidUserId();
		while (flag) {
			System.out.println("|**** Update Details: ****|");
			System.out.println("    1: Update User Contact No.  ");
			System.out.println("    2: Update User Address  ");
			System.out.println("    3: Update User Email Address  ");
			System.out.println("    4: EXIT                    ");

			int choice = getValidChioce();

			switch (choice) {
			case 1:
				for (User user : users) {
					if (user != null && user.getUserId() == user_id) {
						System.out.println("user's contact details to be updated:");
						user.setContactNo(checkMobileNo());
						System.out.println("User contact details successfully updated!!");
						System.out.println("User with updated details: ");
						System.out.println(user);
					}
				}
				break;

			case 2:
				for (User user : users) {
					if (user != null && user.getUserId() == user_id) {
						System.out.println("Enter user's Address details to be updated:");
						user.setUserAddress(sc.next());
						System.out.println("User Address details successfully updated!!");
						System.out.println("User with updated details: ");
						System.out.println(user);
					}
				}
				break;
			case 3:
				for (User user : users) {
					if (user != null && user.getUserId() == user_id) {
						System.out.println("user's email address details to be updated:");
						user.setUserEmailId(validEmail());
						;
						System.out.println("User email address details successfully updated!!");
						System.out.println("User with updated details: ");
						System.out.println(user);
					}
				}
				break;

			case 4:
				flag = false;
				break;

			default:
				System.out.println("Wrong Choice");
				break;

			}

		}
	}

	private int getValidChioce() {
		Scanner sc = new Scanner(System.in);
		System.out.println("*** Enter a valid Choice for action: ***");
		int ch;
		try {
			ch = sc.nextInt();
		} catch (Exception e) {
			System.out.println("Invalid Chioce!!, please reenter it.");
			return getValidChioce();
		}
		return ch;
	}

	@Override
	public void deleteUser() {
		System.out.println("Enter User id you want to delete: ");
		int user_id = getValidUserId();
		/*
		 * for (User user : users) { if (user != null && user_id == user.getUserId()) {
		 * user = null; } }
		 */
		for (int i = 0; i < users.length; i++) {
			User _delete_user = users[i];
			if (_delete_user != null && _delete_user.getUserId() == user_id) {

				users[i] = null;
			}
		}
		System.out.println("User deleted successfully!!");

		System.out.println("Details of Users after deleteing a user with user id: " + user_id + " = ");
		for (User user : users) {
			if (user != null) {
				System.out.println(user);
			}

		}
	}

	public int getValidUserId() {

		int user_id = sc.nextInt();
		boolean flag = false;
		for (User user : users) {
			if (user != null && user.getUserId() == user_id) {
				flag = true;
			}
		}
		if (!flag) {
			System.out.println("Invalid user Id, Please re-enert again..");
			getValidUserId();
		}
		return user_id;
	}

}
