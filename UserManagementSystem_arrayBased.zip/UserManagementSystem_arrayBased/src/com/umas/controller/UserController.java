package com.umas.controller;

import java.util.Scanner;

import com.umas.service.UserService;
import com.umas.service.UserServiceImpl;

public class UserController {

	public static int getValidChioce() {
		Scanner sc = new Scanner(System.in);
		System.out.println("*** Enter a valid Choice for action: ***");
		int ch;
		try {
			ch = sc.nextInt();
		} catch (Exception e) {
			System.out.println("Invalid Chioce!!, please reenter it.");
			return getValidChioce();
		}
		return ch;
	}

	public static void main(String[] args) {
		System.out.println("|*** Welcome To User Management System ***|");

		boolean flag = true;

		UserService s = new UserServiceImpl();

		while (flag) {
			System.out.println(" ");

			System.out.println("1. Add User: ");
			System.out.println("2. Display User: ");
			System.out.println("3. Update User: ");
			System.out.println("4. Delete User: ");
			System.out.println("5. Exit Application");

			int choice = getValidChioce();

			switch (choice) {
			case 1:
				s.insertDetailsOfUser();

				break;
			case 2:
				s.displayDetailsOfUser();

				break;
			case 3:
				s.updateUserDetails();

				break;
			case 4:
				s.deleteUser();

				break;
			case 5:
				flag = false;
				System.out.println("Thank You.");
				break;

			default:
				System.out.println("Wrong Choice");
				break;
			}

		}

	}
}
